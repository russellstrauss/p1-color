import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.lang.reflect.Field;

// This is a Java Color Picker from Oracle Documentation, with an additional
// method to change value in the sketch
public class ColorChooser extends JPanel implements ChangeListener {

    protected JColorChooser tcc;
    protected JLabel banner;
    protected String processingClass;
    protected String colorFieldName;

    public ColorChooser() {
        super(new BorderLayout());

        //Set up the banner at the top of the window
        banner = new JLabel("Java Color Picker",
                JLabel.CENTER);
        banner.setForeground(Color.yellow);
        banner.setBackground(Color.blue);
        banner.setOpaque(true);
        banner.setFont(new Font("SansSerif", Font.BOLD, 24));
        banner.setPreferredSize(new Dimension(100, 65));

        JPanel bannerPanel = new JPanel(new BorderLayout());
        bannerPanel.add(banner, BorderLayout.CENTER);
        bannerPanel.setBorder(BorderFactory.createTitledBorder("Title"));

        //Set up color chooser for setting text color
        tcc = new JColorChooser(banner.getForeground());
        tcc.getSelectionModel().addChangeListener(this);
        tcc.setBorder(BorderFactory.createTitledBorder(
                "Choose Text Color"));

        add(bannerPanel, BorderLayout.CENTER);
        add(tcc, BorderLayout.PAGE_END);
    }

    // An additional constructor to take in the name of class and variable it need to modify
    public ColorChooser(final String className, final String fieldName) {
        this();
        processingClass = className;
        colorFieldName = fieldName;
    }

    public void stateChanged(ChangeEvent e) {
        Color newColor = tcc.getColor();
        banner.setForeground(newColor);
        
        //Every time user picks a color, modify the variable in the sketch class 
        if (processingClass != null && colorFieldName != null) {
            try {
                setInstanceValue(processingClass, colorFieldName, newColor);
            } catch (NoSuchFieldException e1) {
                e1.printStackTrace();
            } catch (ClassNotFoundException e1) {
                e1.printStackTrace();
            } catch (IllegalAccessException e1) {
                e1.printStackTrace();
            }
        }
    }

    // Method actually modify the variable in a given class. The variable modified needs to be static.
    // It uses Java Reflection API. Documentation can be found here: https://docs.oracle.com/javase/tutorial/reflect/
    private void setInstanceValue(final String className, final String fieldName, final Object newValue) throws SecurityException,
            NoSuchFieldException, ClassNotFoundException, IllegalArgumentException, IllegalAccessException {
        // Get the private field
        final Field field = Class.forName(className).getDeclaredField(fieldName);
        // Allow modification on the field
        field.setAccessible(true);
        // Get
        final Object oldValue = field.get(Class.forName(className));
        // Sets the field to the new value
        field.set(oldValue, newValue);
    }

    /**
     * Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event-dispatching thread.
     */
    public static void createAndShowGUI() {
        //Create and set up the window.
        JFrame frame = new JFrame("ColorChooser");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Create and set up the content pane.
        JComponent newContentPane = new ColorChooser();
        newContentPane.setOpaque(true); //content panes must be opaque
        frame.setContentPane(newContentPane);

        //Display the window.
        frame.pack();
        frame.setVisible(true);
    }

    // Create the GUI with the class name and variable name it will modify
    public static void createAndShowGUI(String className, String fieldName) {
        //Create and set up the window.
        JFrame frame = new JFrame("ColorChooser");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Create and set up the content pane.
        JComponent newContentPane = new ColorChooser(className, fieldName);
        newContentPane.setOpaque(true); //content panes must be opaque
        frame.setContentPane(newContentPane);

        //Display the window.
        frame.pack();
        frame.setVisible(true);
    }

    //public static void main(String[] args) {
    //    //Schedule a job for the event-dispatching thread:
    //    //creating and showing this application's GUI.
    //    javax.swing.SwingUtilities.invokeLater(new Runnable() {
    //        public void run() {
    //            createAndShowGUI();
    //        }
    //    });
    //}
}