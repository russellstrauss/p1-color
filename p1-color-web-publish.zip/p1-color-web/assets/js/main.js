var Scene = require('./components/scene.js');
var Utilities = require('./utils.js');

(function () {
	
	document.addEventListener("DOMContentLoaded",function(){

		Scene().init();
	});
	
})();